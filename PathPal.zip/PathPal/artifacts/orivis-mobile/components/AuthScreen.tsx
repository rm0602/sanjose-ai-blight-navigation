import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useEffect, useState } from 'react';
import { Modal, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { BrandMark, Button, Card, Chip, Field } from '@/components/OrivisUI';
import { ROLE_LABELS, type DemoUser, type Role, type FamilyAccountSnapshot, useDemo } from '@/context/DemoContext';
import { useColors } from '@/hooks/useColors';
import {
  createFamily as createFamilyRequest,
  createReportSession,
  getMyFamily,
  joinFamily as joinFamilyRequest,
} from '@workspace/api-client-react';
import { clearReportSession, reportError, saveReportSession } from '@/lib/reportApi';

type AuthMode = 'signin' | 'family' | 'join';

function responseStatus(error: unknown): number | null {
  if (error && typeof error === 'object' && 'status' in error) {
    const status = (error as { status?: unknown }).status;
    if (typeof status === 'number') return status;
  }
  return null;
}

export function AuthScreen({ onVerified }: { onVerified: (account: DemoUser) => void }) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { state, authenticate, syncFamilyFromServer, joinFamily, saveParentProfile } = useDemo();
  const [mode, setMode] = useState<AuthMode>('signin');
  const [role, setRole] = useState<Role | null>(null);
  const [rolePickerVisible, setRolePickerVisible] = useState(false);
  const [username, setUsername] = useState('AI4SG');
  const [password, setPassword] = useState('1234');
  const [familyName, setFamilyName] = useState('The Chen family');
  const [childName, setChildName] = useState('Maya Chen');
  const [parentFirstName, setParentFirstName] = useState('');
  const [parentLastName, setParentLastName] = useState('');
  const [parentEmail, setParentEmail] = useState('');
  const [parentPhone, setParentPhone] = useState('');
  const [invite, setInvite] = useState('');
  const [newUsername, setNewUsername] = useState('maya');
  const [newPassword, setNewPassword] = useState('1234');
  const [error, setError] = useState('');
  const [signingIn, setSigningIn] = useState(false);

  useEffect(() => {
    if (!state.childLogin) return;
    setRole('child');
    setMode('signin');
    setUsername(state.childLogin.username);
    setPassword(state.childLogin.password);
  }, [state.childLogin]);

  const signIn = async () => {
    if (signingIn) return;
    if (!role) {
      setError('Select an account type first.');
      return;
    }
    const familyChildId = role === 'child' ? state.childLogin?.familyChildId : undefined;
    if (
      familyChildId &&
      (username.trim().toLowerCase() !== state.childLogin?.username.toLowerCase() ||
        password !== state.childLogin.password)
    ) {
      setError('Use the child username and password created with the family code.');
      return;
    }
    const account = authenticate(username, password, role);
    if (!account) {
      setError('Use AI4SG and 1234 for this prototype.');
      return;
    }
    setSigningIn(true);
    try {
      try {
        const session = await createReportSession({
          username: role === 'parent' || role === 'child' ? 'AI4SG' : username,
          password: role === 'parent' || role === 'child' ? '1234' : password,
          role,
          ...(familyChildId ? { familyChildId } : {}),
        });
        await saveReportSession(session);
      } catch (error) {
        const detail = reportError(error);
        if (familyChildId) {
          await clearReportSession().catch(() => undefined);
          setError(detail);
          return;
        }
        if (role === 'parent' || role === 'child') {
          await clearReportSession().catch(() => undefined);
          const serviceMessage = `Report service unavailable: ${detail}. You can continue using the local family journey, check-ins, and simulated SOS; reports require a server connection.`;
          setError(serviceMessage);
          onVerified({ ...account, reportServiceUnavailable: true, reportServiceError: serviceMessage });
        } else {
          setError(detail);
        }
        return;
      }

      if (role === 'parent') {
        try {
          let family: FamilyAccountSnapshot;
          try {
            family = await getMyFamily();
          } catch (error) {
            if (responseStatus(error) !== 404) throw error;
            family = await createFamilyRequest({
              familyName: state.familyName.trim() || 'The PathPal family',
              childName: state.child.name.trim() || 'New family member',
            });
          }
          await syncFamilyFromServer(family);
        } catch (error) {
          const familyMessage = `Family code unavailable: ${reportError(error)}. Sign in again when the service is available.`;
          setError(familyMessage);
          onVerified({
            ...account,
            familyServiceUnavailable: true,
            familyServiceError: familyMessage,
          });
          return;
        }
      }

      if (familyChildId) {
        try {
          const family = await getMyFamily();
          await syncFamilyFromServer(family);
        } catch (error) {
          await clearReportSession().catch(() => undefined);
          setError(`Family access unavailable: ${reportError(error)}`);
          return;
        }
      }

      setError('');
      onVerified(account);
    } finally {
      setSigningIn(false);
    }
  };

  const registerFamily = async () => {
    if (signingIn) return;
    if (!parentFirstName.trim() || !parentLastName.trim() || !familyName.trim() || !childName.trim()) {
      setError('Enter your first and last name, a family name, and your child’s name.');
      return;
    }
    setSigningIn(true);
    try {
      const session = await createReportSession({ username: 'AI4SG', password: '1234', role: 'parent' });
      await saveReportSession(session);
      const family = await createFamilyRequest({
        familyName: familyName.trim(),
        childName: childName.trim(),
      });
      await syncFamilyFromServer(family);
      const parentName = `${parentFirstName.trim()} ${parentLastName.trim()}`;
      await saveParentProfile({
        name: parentName,
        email: parentEmail.trim(),
        phone: parentPhone.trim(),
      });
      const account = authenticate('AI4SG', '1234', 'parent');
      if (!account) throw new Error('The parent demo sign-in is unavailable.');
      setRole('parent');
      setMode('signin');
      setError('');
      onVerified({ ...account, name: parentName });
    } catch (error) {
      await clearReportSession().catch(() => undefined);
      setError(reportError(error));
    } finally {
      setSigningIn(false);
    }
  };

  const join = async () => {
    if (signingIn) return;
    if (!invite.trim() || !childName.trim() || newUsername.trim().length < 3 || newPassword.length < 4) {
      setError('Enter a valid family code, name, username, and password.');
      return;
    }
    setSigningIn(true);
    try {
      const family = await joinFamilyRequest({
        invitationCode: invite.trim(),
        childName: childName.trim(),
        username: newUsername.trim(),
      });
      await joinFamily(family, childName, newUsername, newPassword);
      setUsername(newUsername.trim());
      setPassword(newPassword);
      setRole('child');
      setMode('signin');
      setError('');
    } catch (error) {
      setError(reportError(error));
    } finally {
      setSigningIn(false);
    }
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: insets.top + (Platform.OS === 'web' ? 72 : 24),
          paddingBottom: insets.bottom + 28,
        },
      ]}
      bottomOffset={60}
      keyboardShouldPersistTaps="handled"
    >
      <View style={styles.brandRow}>
        <BrandMark size={48} />
        <View>
          <Text style={[styles.brand, { color: colors.foreground }]}>PathPal</Text>
          <Text style={[styles.brandSub, { color: colors.mutedForeground }]}>Move with confidence</Text>
        </View>
      </View>

      <View style={[styles.heroOrb, { backgroundColor: colors.accent }]}>
        <View style={[styles.orbit, { borderColor: colors.primary }]}>
          <View style={[styles.busIcon, { backgroundColor: colors.card }]}>
            <Feather name="navigation" size={27} color={colors.primary} />
          </View>
          <View style={[styles.familyIcon, { backgroundColor: colors.primary }]}>
            <Feather name="users" size={22} color={colors.primaryForeground} />
          </View>
        </View>
      </View>

      <Text style={[styles.heading, { color: colors.foreground }]}>
        {mode === 'signin' ? 'A safer way to get there.' : mode === 'family' ? 'Create your family circle.' : 'Join your family circle.'}
      </Text>
      <Text style={[styles.lead, { color: colors.mutedForeground }]}>
        {mode === 'signin'
          ? 'Coordinate bus journeys, improve your neighborhood, and practice family safety in one calm place.'
          : mode === 'family'
            ? 'A parent starts the family and creates an invitation code for their child.'
            : 'Use a valid invitation code, then create the child’s own demo sign-in.'}
      </Text>

      <Card style={styles.formCard}>
        <Text style={[styles.formTitle, { color: colors.foreground }]}>Select Account Type</Text>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={role ? `Account type: ${ROLE_LABELS[role]}` : 'Select an account type'}
          testID="select-account-type"
          onPress={() => setRolePickerVisible(true)}
          style={({ pressed }) => [
            styles.roleSelect,
            {
              backgroundColor: colors.card,
              borderColor: role ? colors.primary : colors.border,
              opacity: pressed ? 0.78 : 1,
            },
          ]}
        >
          <Feather name={role ? 'user-check' : 'users'} size={19} color={role ? colors.primary : colors.mutedForeground} />
          <Text style={[styles.roleSelectText, { color: role ? colors.foreground : colors.mutedForeground }]}>
            {role ? ROLE_LABELS[role] : 'Choose an account type'}
          </Text>
          {role ? <Feather name="check-circle" size={17} color={colors.primary} /> : null}
          <Feather name="chevron-down" size={17} color={colors.mutedForeground} />
        </Pressable>
        {role ? (
          <View style={[styles.roleHint, { backgroundColor: colors.muted }]}>
            <Feather name="info" size={14} color={colors.primary} />
            <Text style={[styles.roleHintText, { color: colors.mutedForeground }]}>
              {role === 'parent'
                ? 'Parents can sign in or create a family account.'
                : role === 'child'
                  ? 'Children can sign in or join a family with an invitation code.'
                  : 'This account type uses the existing city or community sign-in flow.'}
            </Text>
          </View>
        ) : null}
        {role ? (
          <View style={styles.modeRow}>
            <Chip label="Sign in" active={mode === 'signin'} onPress={() => { setMode('signin'); setError(''); }} />
            {role === 'parent' ? (
              <Chip label="Create family" active={mode === 'family'} onPress={() => { setMode('family'); setError(''); }} />
            ) : null}
            {role === 'child' ? (
              <Chip label="Join family" active={mode === 'join'} onPress={() => { setMode('join'); setError(''); }} />
            ) : null}
          </View>
        ) : null}

        {mode === 'signin' ? (
          <>
            <Field label="Username" value={username} onChangeText={setUsername} autoCapitalize="none" testID="username" />
            <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry testID="password" />
            {role === 'child' && state.childLogin?.familyChildId ? (
              <View style={[styles.demoNote, { backgroundColor: colors.muted }]}>
                <Feather name="info" size={15} color={colors.primary} />
                <Text style={[styles.demoText, { color: colors.mutedForeground }]}>
                  A parent must approve this child before family reports and details are available. Try signing in again after approval.
                </Text>
              </View>
            ) : null}
            {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
            <Button label="Continue securely" icon="arrow-right" onPress={() => { void signIn(); }} loading={signingIn} testID="continue-signin" />
            <View style={[styles.demoNote, { backgroundColor: colors.muted }]}>
              <Feather name="info" size={15} color={colors.primary} />
              <Text style={[styles.demoText, { color: colors.mutedForeground }]}>
                Shared prototype identities: AI4SG · 1234 · verification 1234. Demo accounts are not securely isolated.
              </Text>
            </View>
          </>
        ) : mode === 'family' ? (
          <>
            <Text style={[styles.formTitle, { color: colors.foreground }]}>Parent registration</Text>
            <Field label="First name" value={parentFirstName} onChangeText={setParentFirstName} autoCapitalize="words" testID="parent-first-name" />
            <Field label="Last name" value={parentLastName} onChangeText={setParentLastName} autoCapitalize="words" testID="parent-last-name" />
            <Field label="Email" value={parentEmail} onChangeText={setParentEmail} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} testID="parent-email" />
            <Field label="Phone number" value={parentPhone} onChangeText={setParentPhone} keyboardType="phone-pad" testID="parent-phone" />
            <Field label="Family name" value={familyName} onChangeText={setFamilyName} />
            <Field label="Child’s name" value={childName} onChangeText={setChildName} />
            {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
            <Button label="Create family account" icon="users" loading={signingIn} onPress={() => { void registerFamily(); }} />
          </>
        ) : (
          <>
            <Text style={[styles.formTitle, { color: colors.foreground }]}>Child invitation</Text>
            <Field label="Invitation code" value={invite} onChangeText={setInvite} keyboardType="number-pad" />
            <Field label="Your name" value={childName} onChangeText={setChildName} />
            <Field label="Create username" value={newUsername} onChangeText={setNewUsername} autoCapitalize="none" />
            <Field label="Create password" value={newPassword} onChangeText={setNewPassword} secureTextEntry />
            {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
            <Button label="Join family" icon="user-check" loading={signingIn} onPress={() => { void join(); }} />
          </>
        )}
      </Card>

      <View style={styles.disclaimer}>
        <Feather name="shield" size={15} color={colors.mutedForeground} />
        <Text style={[styles.disclaimerText, { color: colors.mutedForeground }]}>
          Prototype simulation. Not an emergency service or a replacement for trusted adults and local emergency resources.
        </Text>
      </View>
      <Modal
        visible={rolePickerVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setRolePickerVisible(false)}
      >
        <View style={styles.roleModalRoot}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Close account type selection"
            onPress={() => setRolePickerVisible(false)}
            style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(10, 25, 34, 0.48)' }]}
          />
          <View style={[styles.roleSheet, { backgroundColor: colors.card, borderColor: colors.border, paddingBottom: insets.bottom + 18 }]}>
            <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />
            <Text style={[styles.formTitle, { color: colors.foreground }]}>Select Account Type</Text>
            <Text style={[styles.roleSheetSubtitle, { color: colors.mutedForeground }]}>
              Choose the account flow you want to use.
            </Text>
            {(Object.keys(ROLE_LABELS) as Role[]).map((item) => {
              const selected = role === item;
              const icon = item === 'parent'
                ? 'users'
                : item === 'child'
                  ? 'smile'
                  : item === 'manager'
                    ? 'clipboard'
                    : 'tool';
              return (
                <Pressable
                  key={item}
                  accessibilityRole="button"
                  accessibilityState={{ selected }}
                  testID={`role-${item}`}
                  onPress={() => {
                    void Haptics.selectionAsync();
                    setRole(item);
                    setMode('signin');
                    setRolePickerVisible(false);
                    setError('');
                  }}
                  style={[
                    styles.roleOption,
                    {
                      backgroundColor: selected ? colors.secondary : colors.card,
                      borderColor: selected ? colors.primary : colors.border,
                    },
                  ]}
                >
                  <Feather name={icon} size={18} color={selected ? colors.primary : colors.mutedForeground} />
                  <Text style={[styles.roleOptionText, { color: colors.foreground }]}>{ROLE_LABELS[item]}</Text>
                  {selected ? <Feather name="check-circle" size={17} color={colors.primary} /> : null}
                </Pressable>
              );
            })}
          </View>
        </View>
      </Modal>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 20, alignItems: 'stretch' },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  brand: { fontFamily: 'Inter_700Bold', fontSize: 24, letterSpacing: -0.6 },
  brandSub: { fontFamily: 'Inter_500Medium', fontSize: 11, marginTop: 1 },
  heroOrb: { alignSelf: 'center', width: 174, height: 174, borderRadius: 87, marginTop: 32, marginBottom: 25, alignItems: 'center', justifyContent: 'center' },
  orbit: { width: 122, height: 122, borderRadius: 61, borderWidth: 1.5, borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center', transform: [{ rotate: '-10deg' }] },
  busIcon: { width: 64, height: 64, borderRadius: 24, alignItems: 'center', justifyContent: 'center', transform: [{ rotate: '10deg' }] },
  familyIcon: { position: 'absolute', right: -10, bottom: 12, width: 45, height: 45, borderRadius: 18, alignItems: 'center', justifyContent: 'center', transform: [{ rotate: '10deg' }] },
  heading: { fontFamily: 'Inter_700Bold', fontSize: 32, lineHeight: 38, letterSpacing: -1.1, maxWidth: 330 },
  lead: { fontFamily: 'Inter_400Regular', fontSize: 15, lineHeight: 23, marginTop: 10, marginBottom: 22, maxWidth: 350 },
  formCard: { gap: 15 },
  modeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  formTitle: { fontFamily: 'Inter_700Bold', fontSize: 17, marginTop: 2 },
  roleSelect: { minHeight: 54, borderWidth: 1, borderRadius: 16, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 10 },
  roleSelectText: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  roleHint: { borderRadius: 14, padding: 11, flexDirection: 'row', gap: 8, alignItems: 'flex-start' },
  roleHintText: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 11, lineHeight: 16 },
  roleModalRoot: { flex: 1, justifyContent: 'flex-end' },
  roleSheet: { borderTopLeftRadius: 25, borderTopRightRadius: 25, borderWidth: 1, paddingHorizontal: 20, paddingTop: 12, gap: 9 },
  sheetHandle: { alignSelf: 'center', width: 38, height: 4, borderRadius: 2, marginBottom: 5 },
  roleSheetSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 18, marginBottom: 3 },
  roleOption: { minHeight: 51, borderWidth: 1, borderRadius: 16, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 11 },
  roleOptionText: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  error: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  demoNote: { borderRadius: 14, padding: 12, flexDirection: 'row', gap: 8, alignItems: 'flex-start' },
  demoText: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 11, lineHeight: 16 },
  disclaimer: { flexDirection: 'row', gap: 8, marginTop: 20, paddingHorizontal: 8 },
  disclaimerText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17 },
});